
# coding: utf-8

# In[2]:


import numpy as np
A1 = [-1,1,-1,-1,1,-1]
A2 = [-1,-1,1,-1,-1,1]
A3 = [1,-1,-1,1,-1,-1]

B1 = [-1,-1,1]
B2 = [-1,1,-1]
B3 = [1,-1,-1]

M1 = [[x*y for x in A1] for y in B1]

M2 = [[x*y for x in A2] for y in B2]

M3 = [[x*y for x in A3] for y in B3]

M = [[x1 + x2 + x3 for x1,x2,x3 in zip(m1,m2,m3)]for m1,m2,m3 in zip(M1,M2,M3)]

Mt = [[],[],[],[],[],[]]



for i in range(len(M)):
    for j in range(len(M[i])):
        Mt[j].append(M[i][j])
        
        


# In[3]:


def funkcja_aktywacji(x):
    if x > 0:
        return 1
    else:
        return -1
for i in Mt:
    print(i)
    
print ("\n")
for i in M:
    print(i)

Mt = np.array(Mt)
M = np.array(M)
B1 = np.array(B1)
B3 = np.array(B3)
B2 = np.array(B2)
A1 = np.array(A1)
A3 = np.array(A3)
A2 = np.array(A2)
print("\n")
print([funkcja_aktywacji(i) for i in Mt.dot(B1)],end = "\n\n")

print([funkcja_aktywacji(i) for i in Mt.dot(B2)],end = "\n\n")

print([funkcja_aktywacji(i) for i in Mt.dot(B3)],end = "\n\n")

print([funkcja_aktywacji(i) for i in M.dot(A1)],end = "\n\n")
print([funkcja_aktywacji(i) for i in M.dot(A2)],end = "\n\n")
print([funkcja_aktywacji(i) for i in M.dot(A3)],end = "\n\n")


kopia_macierzy = M.copy()
uszkodzony_wzorzec = np.array([0,0.2,0.1,-0.1,1,0.1])
odpowiedz = np.array([funkcja_aktywacji(i) for i in kopia_macierzy.dot(uszkodzony_wzorzec)])
wzorzec = np.array([funkcja_aktywacji(i) for i in kopia_macierzy.transpose().dot(odpowiedz)])
print(wzorzec)
uszkodzony_wzorzec = np.array([0,1,0.1])
odpowiedz = np.array([funkcja_aktywacji(i) for i in kopia_macierzy.transpose().dot(uszkodzony_wzorzec)])
wzorzec = np.array([funkcja_aktywacji(i) for i in kopia_macierzy.dot(odpowiedz)])
print(wzorzec)



# In[5]:


import numpy as np

A1 = np.array([-1,1,-1,-1,1,-1])
A2 = np.array([-1,-1,1,-1,-1,1])
A3 = np.array([1,-1,-1,1,-1,-1])

B1 = np.array([-1,-1,1])
B2 = np.array([-1,1,-1])
B3 = np.array([1,-1,-1])
B1T = B1.reshape(1,3)
A1 = A1.reshape(6,1)
B2T = B2.reshape(1,3)
A2 = A2.reshape(6,1)
B3T = B3.reshape(1,3)
A3 = A3.reshape(6,1)
M1 = np.matmul(A1,B1T)
M2 = np.matmul(A2,B2T)
M3 = np.matmul(A3,B3T)

A1T = A1.reshape(1,6)
A2T = A1.reshape(1,6)
A3T = A1.reshape(1,6)
M = np.add(M1,M2,M3)


    
Mfa = np.array([[funkcja_aktywacji(i) for i in j]for j in M])
A1W = np.matmul(Mfa,B1)

A1W = np.array([funkcja_aktywacji(j) for j in A1W])
A2W = np.matmul(Mfa,B2)

A2W = np.array([funkcja_aktywacji(j) for j in A2W])
A3W = np.matmul(Mfa,B3)

A3W = np.array([funkcja_aktywacji(j) for j in A3W])

MfaT = np.transpose(Mfa)
B1W = np.matmul(MfaT,A1)

B1W = np.array([funkcja_aktywacji(j) for j in B1W])
B2W = np.matmul(MfaT,A2)

B2W = np.array([funkcja_aktywacji(j) for j in B2W])
B3W = np.matmul(MfaT,A3)

B3W = np.array([funkcja_aktywacji(j) for j in B3W])


# In[6]:


print(A1W)
print(A2W)
print(A3W)

