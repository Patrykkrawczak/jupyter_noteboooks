
# coding: utf-8

# In[3]:


import random
import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

class perc:
    def __init__(self,liczba = 2):
        self.x = []
        self.y = []
        self.bl = []
        self.dane_wejsciowe = []
        self.dane_oczekiwane = []
        self.wagi  = [random.random()*4 for x in range(liczba+1)]
        self.wagi[0] = 1
        print(self.wagi)
    def getxybl():
        return (self.x,self.y,self.bl)
    def funkcja_aktywacji(self,liczba):
        if liczba > 0 :
            return 1
        else: 
            return -1
    def calc(self,Xi,W):
        print(Xi)
        print(W)
        res = 0 
        for x in [x*w for x,w in zip(Xi,W)]:
            res += x
        return res
    def suma_wazona(self,dane_wejsciowe):
        suma = 0
        for w,x in zip(self.wagi,dane_wejsciowe):
            suma = suma + w*x
        return suma
        
    def oblicz_blad(self,dane_wejsciowe,dane_oczekiwane):
        bledy = []
        for d,o in zip(dane_wejsciowe,dane_oczekiwane):
            blad = o - self.funkcja_aktywacji(self.suma_wazona(d))
            bledy.append(blad)
        return bledy
    def oblicz_blad2(self,x,y):
        bledy = []
        self.wagi = [1,x,y]
        for d,o in zip(self.dane_wejsciowe,self.dane_oczekiwane):
            blad = o - self.funkcja_aktywacji(self.suma_wazona(d))
            bledy.append(blad**2)
        return sum(bledy)/4
    def czy_zera(self,lista):
        print(lista)
        for i in lista:
            if i != 0 :
                return 1
        return 0
    def ucz(self,dane_wejsciowe,oczekiwane):
        print(self.oblicz_blad(dane_wejsciowe,oczekiwane))
        while self.czy_zera(self.oblicz_blad(dane_wejsciowe,oczekiwane)):
            bledy = self.oblicz_blad(dane_wejsciowe,oczekiwane)
            bledy2 = [b**2 for b in bledy]
            self.bl.append((sum(bledy2)/4))
            self.x.append(self.wagi[1])
            self.y.append(self.wagi[2])

            for pobudzenia,b,ocz in zip(dane_wejsciowe,bledy,oczekiwane):
                bledy = self.oblicz_blad(dane_wejsciowe,oczekiwane)
                bledy2 = [b**2 for b in bledy]
                self.bl.append((sum(bledy2)/4))
                self.x.append(self.wagi[1])
                self.y.append(self.wagi[2])
                nowe_wagi = []
                print("oczekiwany = ",ocz," a błąd wynosi = ",b)
                if b != 0 :
                    print("stare wagi", self.wagi)
                    for x,w in zip(pobudzenia,self.wagi):
                        if ocz > 0 :
                            #wartość bezwzględna z b dlatego (b**2)**(1/2)
                            nowe_wagi.append(w + 0.4*x*(b**2)**(1/2))
                        if ocz <= 0 :
                            nowe_wagi.append(w - 0.4*x*((b**2)**(1/2)))

                    self.wagi = nowe_wagi
                    self.wagi[0] = 1.0
                    bledy = self.oblicz_blad(dane_wejsciowe,oczekiwane)
                    bledy2 = [b**2 for b in bledy]
                    self.bl.append((sum(bledy2)/4))
                    self.x.append(self.wagi[1])
                    self.y.append(self.wagi[2])
                    print("nowe wagi:",self.wagi)
                    if not self.czy_zera(self.oblicz_blad(dane_wejsciowe,oczekiwane)) :
                        bledy = self.oblicz_blad(dane_wejsciowe,oczekiwane)
                        bledy2 = [b**2 for b in bledy]
                        self.bl.append((sum(bledy2)/4))
                        self.x.append(self.wagi[1])
                        self.y.append(self.wagi[2])
                        return
                    
                    


per = perc(3)

X = [[1.0,-1.0,-1.0],[1.0,-1.0,1.0],[1.0,1.0,-1.0],[1.0,1.0,1.0]]
D = [1.0,1.0,1.0,-1.0]
W = [[0,0.25,0.65]]


#per.wagi = W[0]
W[0] = per.wagi.copy()
print(X,"\n",D,"\n",W)
per.ucz(X,D)

print("błąd przed uczeniem: \t",[ d-per.funkcja_aktywacji(per.calc(x,W[-1])) for x,d in zip(X,D)])
print("błąd po uczeniu: \t",per.oblicz_blad(X,D))
x = []
y = []
z = []
ll = np.linspace(-5, 5, 100)
for i in ll:
    for j in ll:
        per.wagi = [1,i,j]
        x.append(i)
        y.append(j)
        o1 = per.oblicz_blad(X,D)
        z.append(sum(x**2 for x in o1)/4)
print(z[1])
ax = plt.axes(projection='3d')

ax.plot_trisurf(x, y, z, alpha=0.5,cmap='viridis', edgecolor='none');
ax.plot(per.x, per.y, per.bl, linewidth=3.5);
plt.show

