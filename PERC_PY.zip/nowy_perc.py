
# coding: utf-8

# In[32]:


import random
import numpy as np
from matplotlib import pyplot as plt


class perc:
    
    def __init__(self,liczba = 2):
        self.suma_kwadratowa_bledow = []
        self.wagi  = [random.random()*4 for x in range(liczba+1)]
        print(self.wagi)
    def funkcja_aktywacji(self,liczba):
        if liczba > 0 :
            return 1
        else: 
            return -1
    def suma_wazona(self,dane_wejsciowe):
        return np.matmul(np.array(self.wagi).reshape(1,-1),np.array(dane_wejsciowe).reshape(-1,1))
        

    def czy_zera(self,lista):
        print(lista)
        for i in lista:
            if i != 0 :
                return 0
        return 1
    
    def ucz(self,X,D):
        while 1:
            suma_bledow = 0
            blad_czesciowy = [d - self.funkcja_aktywacji(self.suma_wazona(x)) for x,d in zip(X,D)]
            self.suma_kwadratowa_bledow.append(sum([b**2 for b in blad_czesciowy])/4)
            for b,x in zip(blad_czesciowy,X):
                if b != 0 :
                    self.wagi = np.add(self.wagi,np.multiply(x,b))
                    print("nowe wagi to: ",self.wagi )
            if self.czy_zera(blad_czesciowy):
                self.suma_kwadratowa_bledow.append(sum([b**2 for b in blad_czesciowy])/4)
                break

                    


per = perc(2)

X = [[1.0,-1.0,-1.0],[1.0,-1.0,1.0],[1.0,1.0,-1.0],[1.0,1.0,1.0]]
D = [1.0,1.0,1.0,-1.0]
W = [[0,0.25,0.65]]


print("błąd przed uczeniem: \t",[ d-per.funkcja_aktywacji(per.suma_wazona(x)) for x,d in zip(X,D)])
#per.wagi = W[0]
W[0] = per.wagi.copy()
print(X,"\n",D,"\n",W)
per.ucz(X,D)
print(X,"\n",D,"\n",per.wagi)
plt.plot(per.suma_kwadratowa_bledow)

print("błąd po uczeniu: \t",[ d-per.funkcja_aktywacji(per.suma_wazona(x)) for x,d in zip(X,D)])

print(per.suma_kwadratowa_bledow)
plt.show()

